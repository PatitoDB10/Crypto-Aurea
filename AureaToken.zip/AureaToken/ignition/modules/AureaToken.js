const { buildModule } = require("@nomicfoundation/hardhat-ignition/modules");

module.exports = buildModule("AureaTokenModule", (m) => {
  // Get the deployer account
  const deployer = m.getAccount(0);
  
  // Get treasury address from parameters, environment, or use deployer as fallback
  const treasuryAddress = m.getParameter(
    "treasuryAddress",
    process.env.TREASURY_ADDRESS || deployer
  );

  // Deploy AureaToken
  const aureaToken = m.contract("AureaToken", [treasuryAddress]);

  return { aureaToken };
});
