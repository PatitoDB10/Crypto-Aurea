const hre = require("hardhat");

// Interactive script to interact with a deployed AureaToken contract
async function main() {
  // Configuration - Update these values
  const CONTRACT_ADDRESS =
    process.env.CONTRACT_ADDRESS || "YOUR_CONTRACT_ADDRESS";

  if (CONTRACT_ADDRESS === "YOUR_CONTRACT_ADDRESS") {
    console.log("❌ Please set CONTRACT_ADDRESS environment variable");
    console.log("   Example: CONTRACT_ADDRESS=0x... node scripts/interact.js");
    process.exit(1);
  }

  console.log("🔗 Connecting to AureaToken at:", CONTRACT_ADDRESS);
  console.log("📡 Network:", hre.network.name);

  const [signer] = await hre.ethers.getSigners();
  console.log("👤 Using account:", signer.address);

  // Connect to the deployed contract
  const AureaToken = await hre.ethers.getContractFactory("AureaToken");
  const aureaToken = AureaToken.attach(CONTRACT_ADDRESS);

  // Read contract information
  console.log("\n📊 Contract Information:");
  const name = await aureaToken.name();
  const symbol = await aureaToken.symbol();
  const totalSupply = await aureaToken.totalSupply();
  const burnRate = await aureaToken.burnRate();
  const treasury = await aureaToken.treasury();
  const owner = await aureaToken.owner();
  const balance = await aureaToken.balanceOf(signer.address);

  console.log("  Name:", name);
  console.log("  Symbol:", symbol);
  console.log(
    "  Total Supply:",
    hre.ethers.formatUnits(totalSupply, 18),
    symbol,
  );
  console.log("  Burn Rate:", burnRate.toString() + "%");
  console.log("  Treasury:", treasury);
  console.log("  Owner:", owner);
  console.log("  Your Balance:", hre.ethers.formatUnits(balance, 18), symbol);

  // Example interactions (uncomment to use)

  // Enviar tokens AUREA a tu wallet
  console.log("\n📤 Enviando tokens AUREA a tu MetaMask...");

  const recipient = process.env.TREASURY_ADDRESS; // tu dirección configurada en .env
  const amount = hre.ethers.parseUnits("1000", 18); // cantidad (1000 AUREA)

  const tx = await aureaToken.transfer(recipient, amount);
  await tx.wait();

  console.log("✅ Transferencia completada!");
  console.log("🔗 Hash:", tx.hash);

  // Example 2: Update burn rate (owner only)
  // console.log("\n⚙️  Updating burn rate...");
  // const newRate = 7;
  // const tx = await aureaToken.updateBurnRate(newRate);
  // await tx.wait();
  // console.log("✅ Burn rate updated to:", newRate + "%");

  // Example 3: Update treasury (owner only)
  // console.log("\n🏦 Updating treasury...");
  // const newTreasury = "0xNewTreasuryAddress";
  // const tx = await aureaToken.updateTreasury(newTreasury);
  // await tx.wait();
  // console.log("✅ Treasury updated to:", newTreasury);

  console.log("\n✅ Script completed!");
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });

