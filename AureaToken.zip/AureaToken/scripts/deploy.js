const hre = require("hardhat");

async function main() {
  console.log("Starting deployment of AureaToken...");

  // Get the treasury address from environment or use deployer as default
  const [deployer] = await hre.ethers.getSigners();
  const treasuryAddress = process.env.TREASURY_ADDRESS || deployer.address;

  console.log("Deploying contracts with the account:", deployer.address);
  console.log("Treasury address:", treasuryAddress);
  console.log("Account balance:", hre.ethers.formatEther(await hre.ethers.provider.getBalance(deployer.address)), "ETH");

  // Deploy the contract
  const AureaToken = await hre.ethers.getContractFactory("AureaToken");
  const aureaToken = await AureaToken.deploy(treasuryAddress);

  await aureaToken.waitForDeployment();

  const contractAddress = await aureaToken.getAddress();
  console.log("\n✅ AureaToken deployed to:", contractAddress);

  // Display contract information
  const name = await aureaToken.name();
  const symbol = await aureaToken.symbol();
  const totalSupply = await aureaToken.totalSupply();
  const burnRate = await aureaToken.burnRate();
  const treasury = await aureaToken.treasury();
  const owner = await aureaToken.owner();

  console.log("\n📊 Contract Information:");
  console.log("  Name:", name);
  console.log("  Symbol:", symbol);
  console.log("  Total Supply:", hre.ethers.formatUnits(totalSupply, 18), symbol);
  console.log("  Burn Rate:", burnRate.toString() + "%");
  console.log("  Treasury:", treasury);
  console.log("  Owner:", owner);

  // Save deployment info
  const deploymentInfo = {
    network: hre.network.name,
    contractAddress: contractAddress,
    deployer: deployer.address,
    treasury: treasuryAddress,
    deployedAt: new Date().toISOString(),
    blockNumber: await hre.ethers.provider.getBlockNumber(),
  };

  console.log("\n📝 Deployment Info:");
  console.log(JSON.stringify(deploymentInfo, null, 2));

  // Wait for block confirmations on testnets/mainnet
  if (hre.network.name !== "hardhat" && hre.network.name !== "localhost") {
    console.log("\n⏳ Waiting for block confirmations...");
    await aureaToken.deploymentTransaction().wait(5);
    console.log("✅ Confirmed!");

    // Verify contract on block explorer if API key is available
    if (process.env.POLYGONSCAN_API_KEY || process.env.BASESCAN_API_KEY) {
      console.log("\n🔍 Verifying contract on block explorer...");
      try {
        await hre.run("verify:verify", {
          address: contractAddress,
          constructorArguments: [treasuryAddress],
        });
        console.log("✅ Contract verified!");
      } catch (error) {
        console.log("❌ Verification failed:", error.message);
      }
    }
  }

  console.log("\n🎉 Deployment completed successfully!");
  
  return contractAddress;
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
