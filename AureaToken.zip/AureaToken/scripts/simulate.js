const hre = require("hardhat");

async function main() {
  console.log("🚀 Starting AureaToken Simulation\n");

  // Get signers
  const [owner, treasury, user1, user2, user3] = await hre.ethers.getSigners();

  console.log("👥 Accounts:");
  console.log("  Owner:", owner.address);
  console.log("  Treasury:", treasury.address);
  console.log("  User1:", user1.address);
  console.log("  User2:", user2.address);
  console.log("  User3:", user3.address);

  // Deploy the contract
  console.log("\n📦 Deploying AureaToken...");
  const AureaToken = await hre.ethers.getContractFactory("AureaToken");
  const aureaToken = await AureaToken.deploy(treasury.address);
  await aureaToken.waitForDeployment();

  const contractAddress = await aureaToken.getAddress();
  console.log("✅ Contract deployed at:", contractAddress);

  // Initial state
  const initialSupply = await aureaToken.totalSupply();
  const ownerBalance = await aureaToken.balanceOf(owner.address);
  const burnRate = await aureaToken.burnRate();

  console.log("\n📊 Initial State:");
  console.log("  Total Supply:", hre.ethers.formatUnits(initialSupply, 18), "AUR");
  console.log("  Owner Balance:", hre.ethers.formatUnits(ownerBalance, 18), "AUR");
  console.log("  Burn Rate:", burnRate.toString() + "%");

  // Simulation 1: Simple transfer
  console.log("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  console.log("📤 Simulation 1: Transfer 10,000 AUR from Owner to User1");
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  
  const amount1 = hre.ethers.parseUnits("10000", 18);
  const tx1 = await aureaToken.transfer(user1.address, amount1);
  await tx1.wait();

  const user1Balance = await aureaToken.balanceOf(user1.address);
  const totalSupply1 = await aureaToken.totalSupply();
  const burned1 = initialSupply - totalSupply1;

  console.log("  Sent:", hre.ethers.formatUnits(amount1, 18), "AUR");
  console.log("  Burned (5%):", hre.ethers.formatUnits(burned1, 18), "AUR");
  console.log("  User1 Received:", hre.ethers.formatUnits(user1Balance, 18), "AUR");
  console.log("  New Total Supply:", hre.ethers.formatUnits(totalSupply1, 18), "AUR");

  // Simulation 2: Chain of transfers
  console.log("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  console.log("📤 Simulation 2: Chain Transfer (User1 → User2 → User3)");
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

  const amount2 = hre.ethers.parseUnits("1000", 18);
  
  // User1 -> User2
  console.log("\n  Step 1: User1 sends 1,000 AUR to User2");
  const tx2 = await aureaToken.connect(user1).transfer(user2.address, amount2);
  await tx2.wait();
  
  const user2Balance = await aureaToken.balanceOf(user2.address);
  console.log("    User2 Received:", hre.ethers.formatUnits(user2Balance, 18), "AUR");

  // User2 -> User3
  console.log("\n  Step 2: User2 sends all to User3");
  const user2BalanceToSend = await aureaToken.balanceOf(user2.address);
  const tx3 = await aureaToken.connect(user2).transfer(user3.address, user2BalanceToSend);
  await tx3.wait();
  
  const user3Balance = await aureaToken.balanceOf(user3.address);
  console.log("    User3 Received:", hre.ethers.formatUnits(user3Balance, 18), "AUR");

  const totalSupply2 = await aureaToken.totalSupply();
  const totalBurned = initialSupply - totalSupply2;
  console.log("\n  Total Burned in Chain:", hre.ethers.formatUnits(totalBurned - burned1, 18), "AUR");

  // Simulation 3: Update burn rate
  console.log("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  console.log("⚙️  Simulation 3: Update Burn Rate to 10%");
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

  const tx4 = await aureaToken.updateBurnRate(10);
  await tx4.wait();
  
  const newBurnRate = await aureaToken.burnRate();
  console.log("  New Burn Rate:", newBurnRate.toString() + "%");

  // Transfer with new burn rate
  console.log("\n  Transfer 5,000 AUR from Owner to User1 with 10% burn");
  const amount3 = hre.ethers.parseUnits("5000", 18);
  const beforeBalance = await aureaToken.balanceOf(user1.address);
  const beforeSupply = await aureaToken.totalSupply();
  
  const tx5 = await aureaToken.transfer(user1.address, amount3);
  await tx5.wait();

  const afterBalance = await aureaToken.balanceOf(user1.address);
  const afterSupply = await aureaToken.totalSupply();
  const received = afterBalance - beforeBalance;
  const burned3 = beforeSupply - afterSupply;

  console.log("    Sent:", hre.ethers.formatUnits(amount3, 18), "AUR");
  console.log("    Burned (10%):", hre.ethers.formatUnits(burned3, 18), "AUR");
  console.log("    Received:", hre.ethers.formatUnits(received, 18), "AUR");

  // Simulation 4: Update treasury
  console.log("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  console.log("🏦 Simulation 4: Update Treasury Address");
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

  const oldTreasury = await aureaToken.treasury();
  const tx6 = await aureaToken.updateTreasury(user2.address);
  await tx6.wait();
  
  const newTreasury = await aureaToken.treasury();
  console.log("  Old Treasury:", oldTreasury);
  console.log("  New Treasury:", newTreasury);

  // Final Summary
  console.log("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  console.log("📈 Final Summary");
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

  const finalSupply = await aureaToken.totalSupply();
  const finalBurned = initialSupply - finalSupply;
  const burnPercentage = (Number(finalBurned) / Number(initialSupply) * 100).toFixed(4);

  console.log("  Initial Supply:", hre.ethers.formatUnits(initialSupply, 18), "AUR");
  console.log("  Final Supply:", hre.ethers.formatUnits(finalSupply, 18), "AUR");
  console.log("  Total Burned:", hre.ethers.formatUnits(finalBurned, 18), "AUR");
  console.log("  Burn Percentage:", burnPercentage + "%");
  console.log("\n  Account Balances:");
  console.log("    Owner:", hre.ethers.formatUnits(await aureaToken.balanceOf(owner.address), 18), "AUR");
  console.log("    User1:", hre.ethers.formatUnits(await aureaToken.balanceOf(user1.address), 18), "AUR");
  console.log("    User2:", hre.ethers.formatUnits(await aureaToken.balanceOf(user2.address), 18), "AUR");
  console.log("    User3:", hre.ethers.formatUnits(await aureaToken.balanceOf(user3.address), 18), "AUR");

  console.log("\n✅ Simulation completed successfully!");
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
