const { expect } = require("chai");
const { ethers } = require("hardhat");
const { loadFixture } = require("@nomicfoundation/hardhat-toolbox/network-helpers");

describe("AureaToken", function () {
  async function deployAureaTokenFixture() {
    const [owner, treasury, addr1, addr2, addr3] = await ethers.getSigners();

    const AureaToken = await ethers.getContractFactory("AureaToken");
    const aureaToken = await AureaToken.deploy(treasury.address);

    return { aureaToken, owner, treasury, addr1, addr2, addr3 };
  }

  describe("Deployment", function () {
    it("Should deploy with correct name and symbol", async function () {
      const { aureaToken } = await loadFixture(deployAureaTokenFixture);
      expect(await aureaToken.name()).to.equal("AUREA");
      expect(await aureaToken.symbol()).to.equal("AUR");
    });

    it("Should mint initial supply to owner", async function () {
      const { aureaToken, owner } = await loadFixture(deployAureaTokenFixture);
      const totalSupply = await aureaToken.totalSupply();
      const ownerBalance = await aureaToken.balanceOf(owner.address);
      
      expect(totalSupply).to.equal(ethers.parseUnits("1000000000", 18));
      expect(ownerBalance).to.equal(totalSupply);
    });

    it("Should set the correct treasury address", async function () {
      const { aureaToken, treasury } = await loadFixture(deployAureaTokenFixture);
      expect(await aureaToken.treasury()).to.equal(treasury.address);
    });

    it("Should set owner correctly", async function () {
      const { aureaToken, owner } = await loadFixture(deployAureaTokenFixture);
      expect(await aureaToken.owner()).to.equal(owner.address);
    });

    it("Should set initial burn rate to 5%", async function () {
      const { aureaToken } = await loadFixture(deployAureaTokenFixture);
      expect(await aureaToken.burnRate()).to.equal(5);
    });

    it("Should revert if treasury is zero address", async function () {
      const AureaToken = await ethers.getContractFactory("AureaToken");
      await expect(
        AureaToken.deploy(ethers.ZeroAddress)
      ).to.be.revertedWith("Treasury cannot be zero address");
    });
  });

  describe("Transfers with Burn Mechanism", function () {
    it("Should burn 5% on transfer", async function () {
      const { aureaToken, owner, addr1 } = await loadFixture(deployAureaTokenFixture);
      const transferAmount = ethers.parseUnits("1000", 18);
      const burnAmount = transferAmount * 5n / 100n;
      const receiveAmount = transferAmount - burnAmount;

      const initialSupply = await aureaToken.totalSupply();

      await aureaToken.transfer(addr1.address, transferAmount);

      expect(await aureaToken.balanceOf(addr1.address)).to.equal(receiveAmount);
      expect(await aureaToken.totalSupply()).to.equal(initialSupply - burnAmount);
    });

    it("Should emit TokensBurned event on transfer", async function () {
      const { aureaToken, owner, addr1 } = await loadFixture(deployAureaTokenFixture);
      const transferAmount = ethers.parseUnits("1000", 18);
      const burnAmount = transferAmount * 5n / 100n;
      const receiveAmount = transferAmount - burnAmount;

      await expect(aureaToken.transfer(addr1.address, transferAmount))
        .to.emit(aureaToken, "TokensBurned")
        .withArgs(owner.address, addr1.address, burnAmount, receiveAmount);
    });

    it("Should handle multiple sequential transfers correctly", async function () {
      const { aureaToken, owner, addr1, addr2 } = await loadFixture(deployAureaTokenFixture);
      const firstTransfer = ethers.parseUnits("1000", 18);
      
      // First transfer: owner -> addr1
      await aureaToken.transfer(addr1.address, firstTransfer);
      const addr1Balance = await aureaToken.balanceOf(addr1.address);
      
      // Second transfer: addr1 -> addr2
      const secondTransfer = ethers.parseUnits("100", 18);
      await aureaToken.connect(addr1).transfer(addr2.address, secondTransfer);
      
      const burnAmount = secondTransfer * 5n / 100n;
      const receiveAmount = secondTransfer - burnAmount;
      
      expect(await aureaToken.balanceOf(addr2.address)).to.equal(receiveAmount);
      expect(await aureaToken.balanceOf(addr1.address)).to.equal(addr1Balance - secondTransfer);
    });

    it("Should calculate burn correctly for different amounts", async function () {
      const { aureaToken, owner, addr1, addr2, addr3 } = await loadFixture(deployAureaTokenFixture);
      
      const amounts = [
        ethers.parseUnits("100", 18),
        ethers.parseUnits("500", 18),
        ethers.parseUnits("1250", 18),
      ];

      for (let i = 0; i < amounts.length; i++) {
        const amount = amounts[i];
        const burnAmount = amount * 5n / 100n;
        const receiveAmount = amount - burnAmount;
        
        const recipient = [addr1, addr2, addr3][i];
        await aureaToken.transfer(recipient.address, amount);
        
        expect(await aureaToken.balanceOf(recipient.address)).to.equal(receiveAmount);
      }
    });
  });

  describe("Burn Rate Management", function () {
    it("Should allow owner to update burn rate", async function () {
      const { aureaToken, owner } = await loadFixture(deployAureaTokenFixture);
      
      await aureaToken.updateBurnRate(3);
      expect(await aureaToken.burnRate()).to.equal(3);
    });

    it("Should emit BurnRateUpdated event", async function () {
      const { aureaToken } = await loadFixture(deployAureaTokenFixture);
      
      await expect(aureaToken.updateBurnRate(7))
        .to.emit(aureaToken, "BurnRateUpdated")
        .withArgs(5, 7);
    });

    it("Should not allow burn rate above 10%", async function () {
      const { aureaToken } = await loadFixture(deployAureaTokenFixture);
      
      await expect(aureaToken.updateBurnRate(11))
        .to.be.revertedWith("Max burn 10%");
    });

    it("Should allow setting burn rate to 0%", async function () {
      const { aureaToken, owner, addr1 } = await loadFixture(deployAureaTokenFixture);
      
      await aureaToken.updateBurnRate(0);
      
      const transferAmount = ethers.parseUnits("1000", 18);
      await aureaToken.transfer(addr1.address, transferAmount);
      
      // With 0% burn, recipient should receive full amount
      expect(await aureaToken.balanceOf(addr1.address)).to.equal(transferAmount);
    });

    it("Should apply new burn rate to subsequent transfers", async function () {
      const { aureaToken, owner, addr1, addr2 } = await loadFixture(deployAureaTokenFixture);
      
      // Transfer with 5% burn
      const firstAmount = ethers.parseUnits("1000", 18);
      await aureaToken.transfer(addr1.address, firstAmount);
      const firstReceived = firstAmount * 95n / 100n;
      expect(await aureaToken.balanceOf(addr1.address)).to.equal(firstReceived);
      
      // Update burn rate to 10%
      await aureaToken.updateBurnRate(10);
      
      // Transfer with 10% burn
      const secondAmount = ethers.parseUnits("1000", 18);
      await aureaToken.transfer(addr2.address, secondAmount);
      const secondReceived = secondAmount * 90n / 100n;
      expect(await aureaToken.balanceOf(addr2.address)).to.equal(secondReceived);
    });

    it("Should not allow non-owner to update burn rate", async function () {
      const { aureaToken, addr1 } = await loadFixture(deployAureaTokenFixture);
      
      await expect(aureaToken.connect(addr1).updateBurnRate(3))
        .to.be.revertedWithCustomError(aureaToken, "OwnableUnauthorizedAccount");
    });
  });

  describe("Treasury Management", function () {
    it("Should allow owner to update treasury address", async function () {
      const { aureaToken, addr1 } = await loadFixture(deployAureaTokenFixture);
      
      await aureaToken.updateTreasury(addr1.address);
      expect(await aureaToken.treasury()).to.equal(addr1.address);
    });

    it("Should emit TreasuryUpdated event", async function () {
      const { aureaToken, treasury, addr1 } = await loadFixture(deployAureaTokenFixture);
      
      await expect(aureaToken.updateTreasury(addr1.address))
        .to.emit(aureaToken, "TreasuryUpdated")
        .withArgs(treasury.address, addr1.address);
    });

    it("Should not allow setting treasury to zero address", async function () {
      const { aureaToken } = await loadFixture(deployAureaTokenFixture);
      
      await expect(aureaToken.updateTreasury(ethers.ZeroAddress))
        .to.be.revertedWith("Treasury cannot be zero address");
    });

    it("Should not allow non-owner to update treasury", async function () {
      const { aureaToken, addr1, addr2 } = await loadFixture(deployAureaTokenFixture);
      
      await expect(aureaToken.connect(addr1).updateTreasury(addr2.address))
        .to.be.revertedWithCustomError(aureaToken, "OwnableUnauthorizedAccount");
    });
  });

  describe("Ownership", function () {
    it("Should allow owner to transfer ownership", async function () {
      const { aureaToken, owner, addr1 } = await loadFixture(deployAureaTokenFixture);
      
      await aureaToken.transferOwnership(addr1.address);
      expect(await aureaToken.owner()).to.equal(addr1.address);
    });

    it("Should not allow non-owner to transfer ownership", async function () {
      const { aureaToken, addr1, addr2 } = await loadFixture(deployAureaTokenFixture);
      
      await expect(aureaToken.connect(addr1).transferOwnership(addr2.address))
        .to.be.revertedWithCustomError(aureaToken, "OwnableUnauthorizedAccount");
    });
  });

  describe("Edge Cases", function () {
    it("Should handle very small transfers correctly", async function () {
      const { aureaToken, owner, addr1 } = await loadFixture(deployAureaTokenFixture);
      
      // Transfer 100 wei (smallest meaningful amount with 5% burn)
      const smallAmount = 100n;
      await aureaToken.transfer(addr1.address, smallAmount);
      
      const burnAmount = smallAmount * 5n / 100n;
      const receiveAmount = smallAmount - burnAmount;
      
      expect(await aureaToken.balanceOf(addr1.address)).to.equal(receiveAmount);
    });

    it("Should handle large transfers correctly", async function () {
      const { aureaToken, owner, addr1 } = await loadFixture(deployAureaTokenFixture);
      
      const largeAmount = ethers.parseUnits("100000000", 18);
      await aureaToken.transfer(addr1.address, largeAmount);
      
      const burnAmount = largeAmount * 5n / 100n;
      const receiveAmount = largeAmount - burnAmount;
      
      expect(await aureaToken.balanceOf(addr1.address)).to.equal(receiveAmount);
    });

    it("Should revert on insufficient balance", async function () {
      const { aureaToken, addr1, addr2 } = await loadFixture(deployAureaTokenFixture);
      
      await expect(
        aureaToken.connect(addr1).transfer(addr2.address, ethers.parseUnits("100", 18))
      ).to.be.revertedWithCustomError(aureaToken, "ERC20InsufficientBalance");
    });
  });

  describe("Total Supply", function () {
    it("Should decrease total supply with each transfer", async function () {
      const { aureaToken, owner, addr1 } = await loadFixture(deployAureaTokenFixture);
      
      const initialSupply = await aureaToken.totalSupply();
      const transferAmount = ethers.parseUnits("1000", 18);
      const burnAmount = transferAmount * 5n / 100n;
      
      await aureaToken.transfer(addr1.address, transferAmount);
      
      expect(await aureaToken.totalSupply()).to.equal(initialSupply - burnAmount);
    });

    it("Should track cumulative burns correctly", async function () {
      const { aureaToken, owner, addr1, addr2, addr3 } = await loadFixture(deployAureaTokenFixture);
      
      const initialSupply = await aureaToken.totalSupply();
      const transferAmount = ethers.parseUnits("1000", 18);
      const burnPerTransfer = transferAmount * 5n / 100n;
      
      await aureaToken.transfer(addr1.address, transferAmount);
      await aureaToken.transfer(addr2.address, transferAmount);
      await aureaToken.transfer(addr3.address, transferAmount);
      
      const expectedSupply = initialSupply - (burnPerTransfer * 3n);
      expect(await aureaToken.totalSupply()).to.equal(expectedSupply);
    });
  });
});
