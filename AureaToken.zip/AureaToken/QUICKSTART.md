# AUREA Token - Quick Start Guide

## 🚀 Get Started in 3 Steps

### 1. Run Tests
```bash
npm test
```
All 27 tests should pass, verifying:
- Token deployment
- 5% burn mechanism
- Owner functions
- Edge cases

### 2. Run Simulation
```bash
npm run simulate
```
This will show you:
- Token transfers with automatic burn
- Burn rate updates
- Treasury management
- Live statistics

### 3. Deploy to Testnet (Optional)

**Setup:**
1. Copy `.env.example` to `.env`
2. Add your wallet private key and treasury address
3. Get testnet tokens from faucets:
   - Polygon Amoy: https://faucet.polygon.technology/
   - Base Sepolia: https://www.coinbase.com/faucets/base-ethereum-goerli-faucet

**Deploy:**
```bash
# Polygon Testnet
npm run deploy:polygonAmoy

# Base Testnet
npm run deploy:baseSepolia
```

## 📊 What You Get

- **Token**: AUREA (AUR) - 1 billion initial supply
- **Burn Rate**: 5% on every transfer (configurable 0-10%)
- **Networks**: Polygon & Base (mainnet + testnets)
- **Testing**: 27 comprehensive tests
- **Scripts**: Deploy, simulate, interact

## 🔧 Useful Commands

```bash
npm run compile        # Compile contracts
npm test              # Run tests
npm run simulate      # Local simulation
npm run node          # Start local node
```

## 📖 Full Documentation

See [README.md](./README.md) for complete documentation.

## ⚠️ Security Notes

- Never commit `.env` with real private keys
- Test on testnets before mainnet
- Consider professional audit for production
- Maximum burn rate is capped at 10%
