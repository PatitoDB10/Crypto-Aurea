# AUREA Token (AUR) - Hardhat Development Environment

A complete Hardhat development environment for the AUREA ERC20 token with a built-in burn mechanism. This project includes smart contracts, comprehensive testing, deployment scripts, and simulation tools.

## Features

- **ERC20 Token**: Standard compliant token with 1 billion initial supply
- **Burn Mechanism**: Configurable burn rate (0-10%) on every transfer
- **OpenZeppelin**: Built with battle-tested OpenZeppelin contracts
- **Comprehensive Tests**: Full test coverage for all functionality
- **Multi-Network Support**: Ready for Polygon and Base networks
- **Simulation Tools**: Interactive scripts to test token behavior

## Token Specifications

- **Name**: AUREA
- **Symbol**: AUR
- **Initial Supply**: 1,000,000,000 AUR
- **Decimals**: 18
- **Default Burn Rate**: 5% per transaction
- **Governance**: Ownable with configurable parameters

## Project Structure

```
├── contracts/
│   └── AureaToken.sol          # Main token contract
├── test/
│   └── AureaToken.test.js      # Comprehensive unit tests
├── scripts/
│   ├── deploy.js               # Deployment script
│   ├── simulate.js             # Local simulation
│   └── interact.js             # Interaction script
├── ignition/
│   └── modules/
│       └── AureaToken.js       # Hardhat Ignition module
├── hardhat.config.js           # Hardhat configuration
└── .env.example                # Environment variables template
```

## Installation

### Prerequisites

- Node.js (v16 or higher)
- npm or yarn

### Setup

1. **Clone or navigate to the project directory**

2. **Install dependencies** (if not already installed):
   ```bash
   npm install
   ```

3. **Configure environment variables**:
   ```bash
   cp .env.example .env
   ```

4. **Edit `.env` file** with your values:
   - `PRIVATE_KEY`: Your wallet private key (for deployment)
   - `TREASURY_ADDRESS`: Address for treasury management
   - `POLYGONSCAN_API_KEY`: For contract verification on Polygon
   - `BASESCAN_API_KEY`: For contract verification on Base

## Usage

### Compile Contracts

```bash
npx hardhat compile
```

### Run Tests

Run the comprehensive test suite:

```bash
npx hardhat test
```

For detailed output with gas reporting:

```bash
REPORT_GAS=true npx hardhat test
```

Run tests with coverage:

```bash
npx hardhat coverage
```

### Local Simulation

Run a complete simulation on a local Hardhat network:

```bash
npx hardhat run scripts/simulate.js
```

This will:
- Deploy the contract locally
- Simulate various transfers with burn mechanics
- Demonstrate burn rate updates
- Show treasury management
- Display final statistics

### Deployment

#### Deploy to Local Network

Start a local Hardhat node:

```bash
npx hardhat node
```

In another terminal, deploy:

```bash
npx hardhat run scripts/deploy.js --network localhost
```

#### Deploy to Polygon Amoy (Testnet)

```bash
npx hardhat run scripts/deploy.js --network polygonAmoy
```

#### Deploy to Base Sepolia (Testnet)

```bash
npx hardhat run scripts/deploy.js --network baseSepolia
```

#### Deploy to Polygon Mainnet

```bash
npx hardhat run scripts/deploy.js --network polygon
```

#### Deploy to Base Mainnet

```bash
npx hardhat run scripts/deploy.js --network base
```

#### Deploy with Hardhat Ignition

Hardhat Ignition provides a declarative deployment system. By default, the module uses the deployer address as the treasury.

Deploy to local network:
```bash
npx hardhat ignition deploy ignition/modules/AureaToken.js --network localhost
```

Deploy with custom treasury address:
```bash
npx hardhat ignition deploy ignition/modules/AureaToken.js --network <network-name> --parameters '{"AureaTokenModule":{"treasuryAddress":"0xYourTreasuryAddress"}}'
```

Or set `TREASURY_ADDRESS` in your `.env` file and deploy:
```bash
npx hardhat ignition deploy ignition/modules/AureaToken.js --network <network-name>
```

### Interact with Deployed Contract

After deployment, interact with your contract:

```bash
CONTRACT_ADDRESS=0x... npx hardhat run scripts/interact.js --network <network-name>
```

Edit `scripts/interact.js` to customize interactions.

## Smart Contract Overview

### AureaToken.sol

The main token contract with the following key features:

#### Constructor
```solidity
constructor(address _treasury)
```
- Mints 1 billion tokens to deployer
- Sets the treasury address
- Initializes burn rate at 5%

#### Transfer Mechanism
Every transfer automatically:
1. Calculates burn amount (transfer amount × burn rate)
2. Burns the calculated amount
3. Transfers the remaining to recipient

Example: Transfer 1000 AUR with 5% burn rate
- Burned: 50 AUR
- Received: 950 AUR

#### Owner Functions

**Update Burn Rate** (0-10%):
```solidity
function updateBurnRate(uint256 newRate) external onlyOwner
```

**Update Treasury**:
```solidity
function updateTreasury(address newTreasury) external onlyOwner
```

#### Events

- `BurnRateUpdated(uint256 oldRate, uint256 newRate)`
- `TreasuryUpdated(address oldTreasury, address newTreasury)`
- `TokensBurned(address indexed from, address indexed to, uint256 burnAmount, uint256 transferAmount)`

## Testing

The test suite covers:

### Deployment Tests
- Correct token name and symbol
- Initial supply minting
- Treasury and owner initialization
- Input validation

### Transfer Tests
- Burn rate application (5% default)
- Multiple sequential transfers
- Different transfer amounts
- Event emissions

### Burn Rate Management
- Owner-only access
- Rate updates (0-10%)
- Rate limits enforcement
- Application to new transfers

### Treasury Management
- Owner-only access
- Address updates
- Zero address validation

### Edge Cases
- Very small transfers
- Large transfers
- Insufficient balance
- Total supply tracking

## Network Configuration

### Supported Networks

| Network | Chain ID | RPC URL |
|---------|----------|---------|
| Hardhat Local | 1337 | N/A |
| Polygon Mainnet | 137 | https://polygon-rpc.com |
| Polygon Amoy | 80002 | https://rpc-amoy.polygon.technology |
| Base Mainnet | 8453 | https://mainnet.base.org |
| Base Sepolia | 84532 | https://sepolia.base.org |

### Getting Testnet Tokens

**Polygon Amoy Testnet**:
- Faucet: https://faucet.polygon.technology/

**Base Sepolia Testnet**:
- Faucet: https://www.coinbase.com/faucets/base-ethereum-goerli-faucet

## Security Considerations

1. **Private Keys**: Never commit `.env` file with real private keys
2. **Treasury Address**: Ensure treasury address is secure and controlled
3. **Burn Rate**: Maximum 10% to prevent excessive token burn
4. **Ownership**: Use multi-sig wallet for production deployments
5. **Audits**: Consider professional audit before mainnet deployment

## Gas Optimization

The contract uses:
- OpenZeppelin's optimized implementations
- Solidity 0.8.20 with optimizer enabled (200 runs)
- Efficient burn mechanism in `_update` override

## Troubleshooting

### Common Issues

**"Insufficient funds" error**:
- Ensure your wallet has enough ETH/MATIC for gas fees

**"Treasury cannot be zero address"**:
- Set a valid treasury address in `.env` or deployment script

**Contract verification failed**:
- Check API keys in `.env`
- Ensure contract is deployed and confirmed
- Wait a few minutes after deployment

**Tests failing**:
- Run `npx hardhat clean` then `npx hardhat compile`
- Ensure all dependencies are installed

## Development Commands

```bash
# Clean artifacts
npx hardhat clean

# Compile contracts
npx hardhat compile

# Run tests
npx hardhat test

# Run specific test file
npx hardhat test test/AureaToken.test.js

# Generate coverage report
npx hardhat coverage

# Start local node
npx hardhat node

# Run console
npx hardhat console --network <network-name>

# Verify contract
npx hardhat verify --network <network> <contract-address> <constructor-args>
```

## License

MIT

## Resources

- [Hardhat Documentation](https://hardhat.org/docs)
- [OpenZeppelin Contracts](https://docs.openzeppelin.com/contracts)
- [Polygon Documentation](https://docs.polygon.technology/)
- [Base Documentation](https://docs.base.org/)
- [Ethers.js Documentation](https://docs.ethers.org/)

## Support

For issues and questions:
1. Check the troubleshooting section
2. Review test files for usage examples
3. Consult Hardhat and OpenZeppelin documentation

## Next Steps

1. **Test Thoroughly**: Run all tests and simulations
2. **Deploy to Testnet**: Test on Polygon Amoy or Base Sepolia
3. **Verify Contract**: Use block explorer verification
4. **Security Audit**: Consider professional audit for production
5. **Monitor**: Track token transfers and burns on block explorer
6. **Community**: Engage with token holders and gather feedback

---

**Built with Hardhat + OpenZeppelin**
