# AUREA Token Development Environment

## Project Overview
A complete Hardhat development environment for the AUREA (AUR) ERC20 token with an integrated burn mechanism. Built with Solidity 0.8.20, OpenZeppelin contracts, and comprehensive testing infrastructure.

## Recent Changes
- **2025-10-28**: Initial project setup with Hardhat 2.19.0
  - Created AureaToken.sol smart contract with 5% burn mechanism
  - Implemented comprehensive test suite (27 tests, all passing)
  - Added deployment scripts for Polygon and Base networks
  - Created simulation and interaction scripts
  - Configured multi-network support (Polygon, Base, testnets)

## Project Architecture

### Smart Contract
- **Location**: `contracts/AureaToken.sol`
- **Features**:
  - ERC20 token standard (OpenZeppelin)
  - Ownable pattern for governance
  - Configurable burn rate (0-10%) on transfers
  - Treasury management
  - Events for all state changes

### Testing
- **Location**: `test/AureaToken.test.js`
- **Coverage**: 27 comprehensive tests covering:
  - Deployment validation
  - Transfer mechanics with burn
  - Owner functions (burn rate, treasury updates)
  - Edge cases and security
  - Total supply tracking

### Scripts
- `scripts/deploy.js` - Production deployment with verification
- `scripts/simulate.js` - Local testing and simulation
- `scripts/interact.js` - Interact with deployed contracts

### Configuration
- **Hardhat**: Version 2.19.0 (CommonJS)
- **Solidity**: 0.8.20 with optimizer (200 runs)
- **Networks**: Polygon (mainnet/Amoy), Base (mainnet/Sepolia)

## Key Commands

### Development
```bash
npm run compile      # Compile contracts
npm run test         # Run test suite
npm run simulate     # Run local simulation
```

### Deployment
```bash
npm run deploy:polygonAmoy    # Deploy to Polygon testnet
npm run deploy:baseSepolia    # Deploy to Base testnet
npm run deploy:polygon        # Deploy to Polygon mainnet
npm run deploy:base           # Deploy to Base mainnet
```

## Environment Variables
See `.env.example` for required configuration:
- `PRIVATE_KEY` - Wallet private key for deployment
- `TREASURY_ADDRESS` - Treasury management address
- `POLYGONSCAN_API_KEY` - For contract verification
- `BASESCAN_API_KEY` - For contract verification

## Token Economics
- **Initial Supply**: 1,000,000,000 AUR
- **Burn Rate**: 5% (configurable 0-10%)
- **Mechanism**: Automatic burn on every transfer
- **Governance**: Owner-controlled parameters

## User Preferences
- Project uses Hardhat 2.x for stability with Node.js 20
- CommonJS module system (require/module.exports)
- Comprehensive testing before any deployment
- Clear documentation and examples

## Next Steps
1. Configure `.env` with deployment credentials
2. Test on testnets (Polygon Amoy or Base Sepolia)
3. Verify contracts on block explorers
4. Consider security audit before mainnet
5. Monitor token metrics and burn statistics
